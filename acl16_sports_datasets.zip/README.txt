This data set contains 150 data examples for 150 football games (1-150). Each example (e.g. 1) corresponds to the following three files: 

1��"1.live.csv": This file contains the live text commentary scripts for the sports game, and the three columns correspond to text scripts, timestamp and the scoreline, respectively. 

2��"1.163.txt": The reference news stories crawled from 163 Football Live (http://goal.sports.163.com/).

3) "1.sina.txt": The reference news stories crawled from Sina Sports Live (http://match.sports.sina.com.cn/).

For any questions about the dataset, please contact Jianmin Zhang (zhangjianmin2015 at pku dot edu dot cn).
